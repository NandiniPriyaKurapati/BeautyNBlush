/*created by Monica Priya Sirinala Devarajulu ID: 700649046
				Tejaswi Byanagari ID: 700647456
				Nandini Kurrapati ID: 700645541 */

// for displaying random image from the set each time the page loads
window.addEventListener("load", function (){
									document.getElementById("loginBtnOffer").addEventListener("click",loginFromOffer,false);
									var img_num = Math.floor(Date.now() / 1000) % 3;
    								document.getElementById("offer_img").src = "img/offer/offer" + img_num + ".jpg";
    								document.getElementById('offer_img').style.width = (screen.availWidth - 17 ) + 'px';
    								document.getElementById('offer_img').style.height = (screen.availHeight - 135) + 'px';
								}, false);
function calculateBMI(){
	//get the height values and weight values entered by user 
    var height1= document.getElementById("heightTxtbox").value;
	var height2= document.getElementById("inchesTxtbox").value;
	var height3= height1 + "." + height2;
	var height= parseFloat(height3);
	var weight= document.getElementById("weightTxtbox").value;

	//resulting your BMI depends on the height and weight
	if(height>0 && weight>0){
		var result= (weight/(height*height)*10);
		if(result<18.5){
			document.getElementById("resultLbl").innerHTML= result.toFixed(2) + "  - you are too thin or underweight";
		}	
		else if(result>18.5 && result<25){
			document.getElementById("resultLbl").innerHTML= result.toFixed(2) +"  - you are healthy";
		}
		else if(result>25){ 
			document.getElementById("resultLbl").innerHTML= result.toFixed(2) +"  - you are overweight";
		}
	}
	else{
		alert("please fill out every box to see your BMI");
	} // end if 

} // end calculateBMI


function loginFromOffer(){ // function if user logs in from Home page
	var userName = document.getElementById('username').value;
    var password = document.getElementById('password').value;

    if (userName == null || userName == '') {
        alert('Please enter User Name');
        return false;
    }

    if (password == null || password == '') {
        alert('Please enter password');
        return false;
    }

    var xhr = new XMLHttpRequest();
	xhr.open("get","credentials.xml", false);
	xhr.send(null);

    
    var users = xhr.responseXML.getElementsByTagName("user");
    for (var i = 0; i < users.length; i++) {
        var data_username = users[i].getElementsByTagName("username")[0].childNodes[0].nodeValue;
        var data_password = users[i].getElementsByTagName("password")[0].childNodes[0].nodeValue;
        if (userName == data_username && password == data_password) {
            isLogin = true;
            
            document.getElementById('loginModule').click();
            document.getElementById('loginTab').style.display = 'none';
			
			localStorage.userNameEntered = userName;
			
            break;
        } else {
            continue;
        }
    }
    if (!isLogin) {  
        alert("Please enter valid credential.");
        return false;
    }
	
} // end login from home


