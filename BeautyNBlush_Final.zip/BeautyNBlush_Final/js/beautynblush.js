/* Java script code for Beauty N Blush
	created by 	Monica Priya Sirinala Devarajulu ID: 700649046
				Tejaswi Byanagari 				 ID: 700647456
				Nandini Kurrapati 				 ID: 700645541 */
//global variables
var isLogin = false;
var itemSeleted = [];
var totalAmount;
var isPayment = false;
var isalreadyLoggedin;
var user;
var asyncRequest;

// variables for startSlider method

var ul;
var li_items;
var imageNumber;
var imageWidth;
var prev, next;
var currentPostion = 0;
var currentImage = 0;

// window load event

window.addEventListener("load" , initialise , false);
//addEventListeners for all other functions
function initialise(){
	 
		startSlider(); // call  the function for images carousel
		document.getElementById("bmiTab").addEventListener("click", function (){
																		startModel('bmiModule');
																	} ,false);
		document.getElementById("loginTab").addEventListener("click",function (){
																		startModel('loginModule');
																	} ,false);
		document.getElementById("loginBtnHome").addEventListener("click",loginFromHome, false);
		document.getElementById("calculateBMIBtn").addEventListener("click",calculateBMI, false);
	
} // end fucntion initialise


function startSlider() {
	// this function is for displaying images in a carousel 
    ul = document.getElementById('image_slider');
    if (ul != null) {
        li_items = ul.children;
        imageNumber = li_items.length;

        for (i = 0; i < imageNumber; i++) {
            li_items[i].children[0].style.width = screen.availWidth + 'px';
            li_items[i].children[0].style.height = (screen.availHeight - 135) + 'px';
        }

        imageWidth = li_items[0].children[0].clientWidth;
        ul.style.width = parseInt(imageWidth * imageNumber) + 'px';
        prev = document.getElementById("prev");
        next = document.getElementById("next");
        
        prev.onclick = function () {
            onClickPrev();
        };
        next.onclick = function () {
            onClickNext();
        };
        var slideInterval = setInterval(onClickNext, 3000);
    }
} //end function startSlider()

function animate(opts) {
    var start = new Date;
    var id = setInterval(function () {
        var timePassed = new Date - start;
        var progress = timePassed / opts.duration;
        if (progress > 1) {
            progress = 1;
        }
        var delta = opts.delta(progress);
        opts.step(delta);
        if (progress == 1) {
            clearInterval(id);
            opts.callback();
        }
    }, opts.delay || 17);
    //return id;
} // end function animate

function slideTo(imageToGo) {
    var direction;
    var numOfImageToGo = Math.abs(imageToGo - currentImage);
    // slide toward left

    direction = currentImage > imageToGo ? 1 : -1;
    currentPostion = -1 * currentImage * imageWidth;
    var opts = {
        duration: 1000,
        delta: function (p) {
            return p;
        },
        step: function (delta) {
            ul.style.left = parseInt(currentPostion + direction * delta * imageWidth * numOfImageToGo) + 'px';
        },
        callback: function () {
            currentImage = imageToGo;
        }
    };
    animate(opts);
} // end function slideTo

function onClickPrev() {
    if (currentImage == 0) {
        slideTo(imageNumber - 1);
    }
    else {
        slideTo(currentImage - 1);
    }
} // function onClickPrev

function onClickNext() {
    if (currentImage == imageNumber - 1) {
        slideTo(0);
    }
    else {
        slideTo(currentImage + 1);
    }
} // function onClickNext

function startModel(name) {
	// load the module basedon the parameter
    var modal = document.getElementById(name);
	//display the module
    modal.style.display = "block";
    window.addEventListener("click", function (event) {
        if (event.target == modal) {
			//hide  the module 
            modal.style.display = "none";
        }
    }, false);
} // function startModel


/* validation */
function isNumberKey(evt) { 
    //var e = evt || window.event;
    var charCode = (evt.which) ? evt.which : evt.keyCode
    if (charCode != 46 && charCode > 31
        && (charCode < 48 || charCode > 57)) {
        return false;
    }
    return true;
} // function isNumberKey

function ValidateAlpha(evt) {
	// function to validate alphabets 
    var keyCode = (evt.which) ? evt.which : evt.keyCode
    if ((keyCode < 65 || keyCode > 90) && (keyCode < 97 || keyCode > 123) && keyCode != 32) {
        return false;
    }
    return true;
} // function ValidateAlpha

/* decimal number validation start */
function validateFloatKeyPress(el, evt) {
    var charCode = (evt.which) ? evt.which : event.keyCode;
    var number = el.value.split('.');
    if (charCode != 46 && charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
    }
    //just one dot
    if (number.length > 1 && charCode == 46) {
        return false;
    }
    //get the carat position
    var caratPos = getSelectionStart(el);
    var dotPos = el.value.indexOf(".");
    if (caratPos > dotPos && dotPos > -1 && (number[1].length > 1)) {
        return false;
    }
    return true;
} // function validateFloatKeyPress

function getSelectionStart(o) {
    if (o.createTextRange) {
        var r = document.selection.createRange().duplicate()
        r.moveEnd('character', o.value.length)
        if (r.text == '') return o.value.length
        return o.value.lastIndexOf(r.text)
    } else return o.selectionStart
}


// for get Services


function getServices(){
	// this function loads the services from XML file and displays in the services.html page
	//raising an async request for xml file
	
	asyncRequest= new XMLHttpRequest;
	asyncRequest.addEventListener("readystatechange", function(){
		if(asyncRequest.readyState== 4 && asyncRequest.status== 200 && asyncRequest.responseXML){
				
				var categories=asyncRequest.responseXML.getElementsByTagName("category"); // this will be an array
				for (var i=0;i<categories.length;i++){		
						var divRowOuterTag = document.createElement("div");
						divRowOuterTag.className='row';
						var name = categories[i].getElementsByTagName("name")[0].childNodes[0].nodeValue;
						var divHeaderTag = document.createElement("div");
						divHeaderTag.className='service_header';
						var nameTag= document.createTextNode(name);	
						divHeaderTag.appendChild(nameTag);
						
						var divDetailTag = document.createElement("div");	
						divDetailTag.className='service_detail';
						var services = categories[i].getElementsByTagName("service");
						for (j=0; j< services.length;j++){
							var service_type = services[j].getElementsByTagName("type")[0].childNodes[0].nodeValue;
							var service_price = services[j].getElementsByTagName("price")[0].childNodes[0].nodeValue;
							var divRowInnerTag = document.createElement("div");
							divRowInnerTag.className='row';
							var divTypeTag= document.createElement("div");
							divTypeTag.className='col-two service_records';
							var divPriceTag = document.createElement("div");
							divPriceTag.className='col-two service_records';
							var typeTextTag= document.createTextNode(service_type);
							var priceTextTag= document.createTextNode(service_price);
							divTypeTag.appendChild(typeTextTag);
							divPriceTag.appendChild(priceTextTag);
							var imgTag= document.createElement("img");
							imgTag.src ="img/cart.png";
							imgTag.id= service_type;
							imgTag.addEventListener("click", function(){
								
								addToCart(this.id);
							}, false);
							//creating division for cart image
							var divCartTag = document.createElement("div");
							divCartTag.className='col-two service_cart';
							divCartTag.appendChild(imgTag);
							divRowInnerTag.appendChild(divTypeTag);
							divRowInnerTag.appendChild(divPriceTag);
							divRowInnerTag.appendChild(divCartTag);	
							divDetailTag.appendChild(divRowInnerTag);
							
						}	// end for
					// append header and details to the outer tag
					divRowOuterTag.appendChild(divHeaderTag);
					divRowOuterTag.appendChild(divDetailTag);
			
				var divServces=document.getElementById("row_data");
				divServces.appendChild(divRowOuterTag);	
						
						
				}	// end for
				divRowOuterTag.appendChild(divHeaderTag);
							divRowOuterTag.appendChild(divDetailTag);
				
				var divServces=document.getElementById("row_data");
				divServces.appendChild(divRowOuterTag);
		} // end if
		
		
	}, false);// eventlistener and call back
	asyncRequest.open("GET", "services.xml", true);
	asyncRequest.send(null);
	}

function addToCart(selectedid)
{
	// function to add elements to the cart when user selects a service
	var asyncRequestAddCart= new XMLHttpRequest;
		// sync call to get the services from xml
		asyncRequestAddCart.open("GET","services.xml", false);
		asyncRequestAddCart.send(null);
		var categoriesAddToCart=asyncRequestAddCart.responseXML.getElementsByTagName("category");
			for (var i=0;i<categoriesAddToCart.length;i++){
				var nameAddToCart = categoriesAddToCart[i].getElementsByTagName("name")[0].childNodes[0].nodeValue;
				var services = categoriesAddToCart[i].getElementsByTagName("service");
				for (j=0; j< services.length;j++){
					var service_type_addToCart = services[j].getElementsByTagName("type")[0].childNodes[0].nodeValue;
					var service_price_addToCart = services[j].getElementsByTagName("price")[0].childNodes[0].nodeValue;
					if(selectedid==service_type_addToCart ){
						// add the services to the obj as and when user selects the services
						var obj = {"id": itemSeleted.length, "name": nameAddToCart, "type": service_type_addToCart, "val": service_price_addToCart};
						itemSeleted[itemSeleted.length] = obj; // itemSeleted array has the services
						document.getElementById('selected_item').innerHTML = itemSeleted.length;
						
					} // end if
					
				} //end inner for
				
			} // end outer for
} // end addToCart

function login() { // this is login from the servies page 
	if(isalreadyLoggedin == true){
		// check if user is already logged in from home
		document.getElementById('user_name_p').innerHTML = "Hello, " + userName;
            document.getElementById('loginModule').click();
            document.getElementById('li_login').style.display = 'none';
            if (isPayment) {
                goForPayment(); // allow user to go to payment 
            }
	}
	else{
    var userName = document.getElementById('username').value;
    var password = document.getElementById('password').value;

    if (userName == null || userName == '') { // nothig is entered
        alert('Please enter User Name');
        return false;
    }

    if (password == null || password == '') { // nothig is entered
        alert('Please enter password');
        return false;
    }
     
    var xhr = new XMLHttpRequest();
	xhr.open("get","credentials.xml", false);
	xhr.send(null);

    
    var users = xhr.responseXML.getElementsByTagName("user");
    for (var i = 0; i < users.length; i++) {
        var data_username = users[i].getElementsByTagName("username")[0].childNodes[0].nodeValue;
        var data_password = users[i].getElementsByTagName("password")[0].childNodes[0].nodeValue;
        if (userName == data_username && password == data_password) {
            isLogin = true;
            document.getElementById('user_name_p').innerHTML = "Hello, " + userName;
            document.getElementById('loginModule').click();
            document.getElementById('li_login').style.display = 'none';
            if (isPayment) { // flag set in checklogin function 
                goForPayment();
            }
            break;
        } else {
            continue;
        }
    } // end for
    if (!isLogin) {
        alert("Please enter valid credential.");
        return false;
    } // end if
	} //end if
} // end login

function loginFromHome(){ // function if user logs in from Home page
	var userName = document.getElementById('username').value;
    var password = document.getElementById('password').value;

    if (userName == null || userName == '') {
        alert('Please enter User Name');
        return false;
    }

    if (password == null || password == '') {
        alert('Please enter password');
        return false;
    }

    var xhr = new XMLHttpRequest();
	xhr.open("get","credentials.xml", false);
	xhr.send(null);

    
    var users = xhr.responseXML.getElementsByTagName("user");
    for (var i = 0; i < users.length; i++) {
        var data_username = users[i].getElementsByTagName("username")[0].childNodes[0].nodeValue;
        var data_password = users[i].getElementsByTagName("password")[0].childNodes[0].nodeValue;
        if (userName == data_username && password == data_password) {
            isLogin = true;
            
            document.getElementById('loginModule').click();
            document.getElementById('loginTab').style.display = 'none';
			// store the username in localstorage 
			localStorage.userNameEntered = userName;
			
            break;
        } else {
            continue;
        } // end if /else 
    } // end for 
    if (!isLogin) {  
        alert("Please enter valid credential.");
        return false;
    }
	
} // end login from home

/* payment*/
function checkLogin() {
    if (itemSeleted.length == 0) {
        alert("Please select at least one item");
        return false;
    }
	if(localStorage.userNameEntered!= null){
		goForPayment();
	}else{
    if (!isLogin) {
        startModel('loginModule');
    } else {
        goForPayment();
    }
	}
    isPayment = true;
} // end checkLogin


function goForPayment(){
	
	var total= 0; // variable for total amount 

	document.getElementById("order_data").innerHTML=""; // empty the division innerhtml
	document.getElementById('row_data').style.display = 'none';
    document.getElementById('pay_text').style.display = 'none';
    document.getElementById('order_data').style.display = '';
    document.getElementById('header_tag').innerHTML = 'Order Details';
	var orderDivTag = document.getElementById("order_data");
	
	var firstOuterDiv = document.createElement("div");
	firstOuterDiv.className = "row";
	
	
	var orderDetailsDiv= document.createElement("div");
	orderDetailsDiv.className="service_detail";
	var totalDiv= document.createElement("div");
	totalDiv.className="service_header";
	totalDiv.id= "service_total";
	var totalTextNode = document.createTextNode("Total Amount");
	totalDiv.appendChild(totalTextNode);
	
	for(var m=0; m < itemSeleted.length ;m++){
		
		var innerDivTag= document.createElement("div");
		innerDivTag.className="row";
		var obj = itemSeleted[m];
        var id = obj.id;
        var name = obj.name;
        var service_type = obj.type;
        var service_price = obj.val;	
		
		var nameTextNode = document.createTextNode(name);
		var nameDivTag = document.createElement("div");
		nameDivTag.className="col-three service_records";
		nameDivTag.appendChild(nameTextNode);
		
		var typeTextNode = document.createTextNode(service_type);
		var typeDivTag = document.createElement("div");
		typeDivTag.className="col-three service_records";
		typeDivTag.appendChild(typeTextNode);
		
		var priceTextNode = document.createTextNode(service_price);
		var priceDivTag = document.createElement("div");
		priceDivTag.className="col-three service_records";
		priceDivTag.appendChild(priceTextNode);
		
		var removeDivTag = document.createElement("div");
		removeDivTag.className= "col-three service_records";
		var removeTextNode = document.createTextNode("Remove");
		var deleteTag = document.createElement("a");
		deleteTag.setAttribute("href" , "#");
		deleteTag.id= id;
		deleteTag.addEventListener("click", function (){
												remove(event, this.id);
											}, false);
	  
		deleteTag.appendChild(removeTextNode);
		removeDivTag.appendChild(deleteTag);
		//appends
		
		innerDivTag.appendChild(nameDivTag);
		innerDivTag.appendChild(typeDivTag);
		innerDivTag.appendChild(priceDivTag);
		innerDivTag.appendChild(removeDivTag);
		orderDetailsDiv.appendChild(innerDivTag);
		 total += parseFloat(service_price);
    }
	
	firstOuterDiv.appendChild(totalDiv);
	firstOuterDiv.appendChild(orderDetailsDiv);
	
	
	
	// starting code for second outer div
	
	var secondOuterDiv = document.createElement("div");
	secondOuterDiv.id = "address_detail";
	
	var firstRowTag = document.createElement("div");
	firstRowTag.className="row";
	
	var firstServiceHeaderTag = document.createElement("div");
	firstServiceHeaderTag.className="service_header";
	
	var addressTextNode = document.createTextNode("Address");
	var address1TextBoxTag= document.createElement("input");
	address1TextBoxTag.type="text";
	address1TextBoxTag.name="address1";
	address1TextBoxTag.id="address1";
	address1TextBoxTag.className="form_input left-margin";
	address1TextBoxTag.placeholder="Address Line 1";
	var address2TextBoxTag=document.createElement("input");
	address2TextBoxTag.type="text";
	address2TextBoxTag.name="address2";
	address2TextBoxTag.id="address2";
	address2TextBoxTag.className="form_input left-margin";
	address2TextBoxTag.placeholder="Address Line 2";
	
	firstServiceHeaderTag.appendChild(addressTextNode);
	firstServiceHeaderTag.appendChild(address1TextBoxTag);
	firstServiceHeaderTag.appendChild(address2TextBoxTag);
	
	firstRowTag.appendChild(firstServiceHeaderTag);
	
	
	
	var secondRowTag = document.createElement("div");
	secondRowTag.className="row";
	
	var secondServiceHeaderTag = document.createElement("div");
	secondServiceHeaderTag.className="service_header";
	
	//code for promo section
	var promoTextNodeTag= document.createTextNode("Promo Code");
	var promoTag = document.createElement("input");
	promoTag.type="text";
	promoTag.name="promocode";
	promoTag.id="promocode";
	promoTag.placeholder="Enter promo code ";
	promoTag.className="form_input left-margin";
	var applyButtonTag = document.createElement("input");
	applyButtonTag.type="button";
	applyButtonTag.id="promoBtn";
	applyButtonTag.value="Apply";
	applyButtonTag.className="pay_btn btn";
	applyButtonTag.addEventListener("click", function (){
	applyPromoCode(event)}, false);
	
	secondServiceHeaderTag.appendChild(promoTextNodeTag);
	secondServiceHeaderTag.appendChild(promoTag);
	secondServiceHeaderTag.appendChild(applyButtonTag);
	secondRowTag.appendChild(secondServiceHeaderTag);
	
	//code for third section
	var thirdRowTag = document.createElement("div");
	thirdRowTag.className="row";
	
	var thirdServiceHeaderTag = document.createElement("div");
	thirdServiceHeaderTag.className="service_header";
	thirdServiceHeaderTag.id="order_conf_section";
	
	var locationTextNode = document.createTextNode("Location:");
	var selectTag= document.createElement("select");
	selectTag.className="form_select";
	selectTag.id="location";
	selectTag.name="location";
	
	selectTag.addEventListener("change", function (){
		var selIndex= selectTag.selectedIndex;
		var minsToReach= selectTag.options[selIndex].value;
	
		document.getElementById('est_txt').innerHTML = "You delivery estimated time :  " + minsToReach + "mins";
	}, false);
	//async Request to get the locations from xml
	var asyncRequestLocation = new XMLHttpRequest();
	asyncRequestLocation.addEventListener("readystatechange", function(){
		if(asyncRequestLocation.readyState== 4 && asyncRequestLocation.status== 200 && asyncRequestLocation.responseXML){
			var locationsArray;
			locationsArray = asyncRequestLocation.responseXML.getElementsByTagName("location");
			for (var n=0; n< locationsArray.length ;++n){
				var landmark= locationsArray.item(n).getElementsByTagName("landmark").item(0).firstChild.nodeValue;
				var mins = locationsArray.item(n).getElementsByTagName("duration").item(0).firstChild.nodeValue;
				var optionTag= document.createElement("option");
				// add value and text to option tag
				optionTag.value= mins;
				optionTag.innerHTML= landmark;
				selectTag.appendChild(optionTag);	
			} // end for
			
		}       // end if
		}, false);
		
	asyncRequestLocation.open("GET", "location.xml", true);
	asyncRequestLocation.send(null);
	
    var estimatedParaTag = document.createElement("p");
	estimatedParaTag.id="est_txt";
	estimatedParaTag.className="p_block est_txt";
	estimatedParaTag.innerHTML ="Your delivery estimated time is ";
	
	var proceedButtonTag = document.createElement("input");
	proceedButtonTag.className="pay_btn btn";
	proceedButtonTag.type="button";
	proceedButtonTag.value="Proceed";
	proceedButtonTag.addEventListener("click", placeOrder , false);
	
	thirdServiceHeaderTag.appendChild(locationTextNode);
	thirdServiceHeaderTag.appendChild(selectTag);
	thirdServiceHeaderTag.appendChild(estimatedParaTag);
	thirdServiceHeaderTag.appendChild(proceedButtonTag);
	
	thirdRowTag.appendChild(thirdServiceHeaderTag);
		
	secondOuterDiv.appendChild(firstRowTag);
	secondOuterDiv.appendChild(secondRowTag);
	secondOuterDiv.appendChild(thirdRowTag);
	
	orderDivTag.appendChild(firstOuterDiv);
	orderDivTag.appendChild(secondOuterDiv);
	
	totalAmount = total;
    
    document.getElementById("service_total").innerHTML = "Total Amount: " + total;
   
} // end goForPayment

function applyPromoCode(event) {
	// function to get the promocode entered and reduce the amount based on the code
    event.preventDefault();
	var dis =0;
	var payable =0;
    var promocode = document.getElementById('promocode').value;
    if (promocode != null && promocode == 'FESTIVE') {
	 dis = ((totalAmount * 5) / 100);
	 payable = (totalAmount - dis);
     document.getElementById("service_total").innerHTML = "Total Payable Amount: $ " + payable + "(" + totalAmount + " - " + dis + ") : Promocode " + promocode + " applied";
	}
	else if(promocode != null && promocode == 'MAKEUP10'){
		dis = ((totalAmount * 10) / 100);
		payable = (totalAmount - dis);
     document.getElementById("service_total").innerHTML = "Total Payable Amount: $ " + payable + "(" + totalAmount + " - " + dis + ") : Promocode " + promocode + " applied";
	}
	else if(promocode != null && promocode == 'HAIRCARE10'){ 
		dis = ((totalAmount * 10) / 100);
		payable = (totalAmount - dis);
     document.getElementById("service_total").innerHTML = "Total Payable Amount: $ " + payable + "(" + totalAmount + " - " + dis + ") : Promocode " + promocode + " applied";
	}
	
	else if(promocode == null){  
		
		document.getElementById("service_total").innerHTML = "Total Payable Amount: $ " + totalAmount + " No Code Applied";
	}
	else{
		alert("Invalid Promocode");
		document.getElementById("service_total").innerHTML = "Total Payable Amount: $ " + totalAmount;
    }
} // end applyPromoCode



function remove(event, id) { 
// function to remove the services
    event.preventDefault();
    if (itemSeleted.length == 1) {
        alert("Order must contain at least 1 item.");
        return false
    }
    for (var j = 0; j < itemSeleted.length; j++) {
        var obj = itemSeleted[j];
        var tmp_id = obj.id;
        console.log(tmp_id)
        console.log(id)
        console.log(tmp_id == id)
        if (tmp_id == id) {
            itemSeleted.splice(j, 1); // reduce the element by 1
            break;
        }

    }
    document.getElementById('selected_item').innerHTML = itemSeleted.length;
    goForPayment();
	flag = "yes";
} // end remove function


function placeOrder(){
	// function called when proceed is clicked
	var min = document.getElementById('location').value;
    var address1 = document.getElementById('address1').value;
    var address2 = document.getElementById('address2').value;
    if (address1 == null || address1 == '') {
        alert('Please enter your address');
        document.getElementById('address1').focus();
        return false;
    }
    if (min == 0) {
        alert('Please select your location');
        document.getElementById('location').focus();
        return false;
    }
    proceedToPayment(min);
} // end placeOrder

function proceedToPayment(min){
	
	document.getElementById('header_tag').innerHTML = 'Payment';
	document.getElementById("address_detail").innerHTML ="";
	
	var paymentDivRow= document.createElement("div");
	paymentDivRow.className="row";
	
	//code for card number division
	var cardNumDiv= document.createElement("div");
	cardNumDiv.className="service_header";
	var cardNumTextNode = document.createTextNode("Card Number");
	var cardNumInputTag= document.createElement("input");
	cardNumInputTag.type="text";
	cardNumInputTag.name="cardno";
	cardNumInputTag.id="cardno";
	cardNumInputTag.className="form_input left-margin pay_form";
	cardNumInputTag.placeholder="Card Number ";
	cardNumInputTag.setAttribute("maxlength",16);
	cardNumInputTag.onkeypress="return isNumberKey(event);";
	
	cardNumDiv.appendChild(cardNumTextNode);
	cardNumDiv.appendChild(cardNumInputTag);
	
	//function for card name division
	var cardNameDiv= document.createElement("div");
	cardNameDiv.className="service_header";
	var cardNameTextNode = document.createTextNode("Name on the card ");
	var cardNameInputTag= document.createElement("input");
	cardNameInputTag.type="text";
	cardNameInputTag.name="cardname";
	cardNameInputTag.id="cardname"
	cardNameInputTag.className="form_input left-margin pay_form";
	cardNameInputTag.placeholder="Card Name ";
	cardNameInputTag.setAttribute("maxlength",50);
	cardNameInputTag.onkeypress="return ValidateAlpha(event);";
	
	cardNameDiv.appendChild(cardNameTextNode);
	cardNameDiv.appendChild(cardNameInputTag);
	
	//code for expiry date
	var expiryDivTag= document.createElement("div");
	expiryDivTag.className="service_header";
	
	var expiryTextNode = document.createTextNode("Expiry Date");
	var monthSelectTag= document.createElement("select");
	monthSelectTag.className="pay_select";
	monthSelectTag.id="month";
	monthSelectTag.name="month";
	var monthOptionTag= document.createElement("option");
	monthOptionTag.value="";
	monthOptionTag.innerHTML="MM";
	var janOptionTag= document.createElement("option");
	janOptionTag.value="1";
	janOptionTag.innerHTML="JAN";
	var febOptionTag= document.createElement("option");
	febOptionTag.value="2";
	febOptionTag.innerHTML="FEB";
	var marOptionTag= document.createElement("option");
	marOptionTag.value="3";
	marOptionTag.innerHTML="MAR";
	var aprlOptionTag= document.createElement("option");
	aprlOptionTag.value="4";
	aprlOptionTag.innerHTML="APR";
	var mayOptionTag= document.createElement("option");
	mayOptionTag.value="5";
	mayOptionTag.innerHTML="MAY";
	var junOptionTag= document.createElement("option");
	junOptionTag.value="6";
	junOptionTag.innerHTML="JUN";
	var julOptionTag= document.createElement("option");
	julOptionTag.value="7";
	julOptionTag.innerHTML="JUL";
	var augOptionTag= document.createElement("option");
	augOptionTag.value="8";
	augOptionTag.innerHTML="AUG";
	var sepOptionTag= document.createElement("option");
	sepOptionTag.value="9";
	sepOptionTag.innerHTML="SEP";
	var octOptionTag= document.createElement("option");
	octOptionTag.value="10";
	octOptionTag.innerHTML="OCT";
	var novOptionTag= document.createElement("option");
	novOptionTag.value="11";
	novOptionTag.innerHTML="NOV";
	var decOptionTag= document.createElement("option");
	decOptionTag.value="12";
	decOptionTag.innerHTML="DEC";
	monthSelectTag.appendChild(monthOptionTag);
	monthSelectTag.appendChild(janOptionTag);
	monthSelectTag.appendChild(febOptionTag);
	monthSelectTag.appendChild(marOptionTag);
	monthSelectTag.appendChild(aprlOptionTag);
	monthSelectTag.appendChild(mayOptionTag);
	monthSelectTag.appendChild(junOptionTag);
	monthSelectTag.appendChild(julOptionTag);
	monthSelectTag.appendChild(augOptionTag);
	monthSelectTag.appendChild(sepOptionTag);
	monthSelectTag.appendChild(octOptionTag);
	monthSelectTag.appendChild(novOptionTag);
	monthSelectTag.appendChild(decOptionTag);
	
	//code for expiry year
	var yearSelectTag= document.createElement("select");
	yearSelectTag.className="pay_select";
	yearSelectTag.id="year";
	yearSelectTag.name="year";
	for( var z=2016; z< 2025 ;z++){
		var yearOptionTag= document.createElement("option");
		yearOptionTag.value= z;
		yearOptionTag.innerHTML=z;
		yearSelectTag.appendChild(yearOptionTag);
	}
	
	expiryDivTag.appendChild(expiryTextNode);
	expiryDivTag.appendChild(monthSelectTag);
	expiryDivTag.appendChild(yearSelectTag);
	// CVV
	var cvvDivTag = document.createElement("div");
	cvvDivTag.className ="service_header";
	var cvvTextNodeTag = document.createTextNode("CVV");
	var cvvInputTag = document.createElement("input");
	cvvInputTag.type ="text";
	cvvInputTag.name="cvv";
	cvvInputTag.id="cvv";
	cvvInputTag.className="form_input_cvv";
	cvvInputTag.placeholder ="CVV";
	cvvInputTag.setAttribute("maxlength",3);
	cvvInputTag.onkeypress = "return isNumberKey(event)";
	
	cvvDivTag.appendChild(cvvTextNodeTag);
	cvvDivTag.appendChild(cvvInputTag);
	
	//place order
	var placeOrderDivTag = document.createElement("div");
	placeOrderDivTag.className="service_header";
	var placeOrderBtnTag =document.createElement("input");
	placeOrderBtnTag.type ="button";
	placeOrderBtnTag.className ="final_pay_btn btn";
	placeOrderBtnTag.value ="Place Order";
	placeOrderBtnTag.addEventListener ("click", function(){finalOrder(min);}, false);

	placeOrderDivTag.appendChild(placeOrderBtnTag);
	
	
	
	paymentDivRow.appendChild(cardNumDiv);
	paymentDivRow.appendChild(cardNameDiv);
	paymentDivRow.appendChild(expiryDivTag);
	paymentDivRow.appendChild(cvvDivTag);
	paymentDivRow.appendChild(placeOrderDivTag);
	
	var addTag= document.getElementById('address_detail');
	addTag.appendChild(paymentDivRow);	
} // end proceedToPayment

function finalOrder(min){
	//check if all the validations are correct
	var cardno = document.getElementById('cardno').value;
    var cardname = document.getElementById('cardname').value;
    var month = document.getElementById('month').value;
    var year = document.getElementById('year').value;
    var cvv = document.getElementById('cvv').value;

    if (cardno == null || cardno == '') {
        alert('Please enter card number.');
        document.getElementById('cardno').focus();
        return false;
    }
	if( !parseInt(cardno) ){
		alert("Please enter only digits");
		document.getElementById('cardno').focus();
		return false;
	}
    if (cardno.length < 16 || cardno.length > 16) {
            alert('Card number should be 16 digits.');
            document.getElementById('cardno').focus();
            return false;
    }
    
    if (cardname == null || cardname == '') {
        alert('Please enter name on card.');
        document.getElementById('cardname').focus();
        return false;
    }
    if (month == null || month == '') {
        alert('Please select MM.');
        document.getElementById('month').focus();
        return false;
    }
    if (year == null || year == '') {
        alert('Please select YYYY.');
        document.getElementById('year').focus();
        return false;
    }
    if (cvv == null || cvv == '') {
        alert('Please enter cvv.');
        document.getElementById('cvv').focus();
        return false;
    } else {
        if (cvv.length < 3 || cvv.length > 3) {
            alert('CVV should be 3 digits.');
            document.getElementById('cvv').focus();
            return false;
        }
    }
	var orderNumber = Math.floor(1+(Math.random()*2000)); // generate a random number as confirmation number
    document.getElementById('address_detail').innerHTML = "Your order with confirmation number BNB"+orderNumber+"001  has been place successfully. We will catch you in " + min + " min.";
    document.getElementById('address_detail').style.backgroundColor = "#dff0d8";
    document.getElementById('address_detail').style.padding = "10px";
    document.getElementById('address_detail').style.margin = "0px -15px";
    document.getElementById('address_detail').style.fontWeight = "bold";
} // end final order function 


function register(){
	// validation for new users 
	var userName = document.getElementById('usernameRegister').value;
    var password = document.getElementById('passwordRegister').value;
	var confirmPassword = document.getElementById('confirmpasswordRegister').value;
	var emailID = document.getElementById('emailID').value;
      if (password != confirmPassword) {
        alert('passwords are not matching');
        return false;
    }

} // end function register