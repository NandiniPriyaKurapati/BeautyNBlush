/*created by Monica Priya Sirinala Devarajulu ID: 700649046
				Tejaswi Byanagari ID: 700647456
				Nandini Kurrapati ID: 700645541 */

//window load event
window.addEventListener("load" , initialise , false);

function initialise(){
	//call the function to load services
	getServices();
	//get the username from local storage if the user already logged in from home page
	 var userNameEntered= localStorage.userNameEntered;
		if(userNameEntered!= null){
			document.getElementById('user_name_p').innerHTML = "Hello, " + userNameEntered;
            document.getElementById('loginModule').click();
            document.getElementById('li_login').style.display = 'none';
	}
	document.getElementById("calculateBMIBtnServices").addEventListener("click",calculateBMI, false);
	document.getElementById("loginBtnServices").addEventListener("click", login, false);

} //end function initialise
	
	
function calculateBMI() {
	//get the height values and weight values entered by user 
	
    var height1= document.getElementById("heightTxtbox").value;
	var height2= document.getElementById("inchesTxtbox").value;
	var height3= height1 + "." + height2;
	var height= parseFloat(height3);
	var weight= document.getElementById("weightTxtbox").value;

//resulting your BMI depends on the height and weight

	if(height>0 && weight>0){
		var result= (weight/(height*height)*10);
		if(result<18.5){
			document.getElementById("resultLbl").innerHTML= result.toFixed(2) + "  - you are too thin or underweight";
		}	
		else if(result>18.5 && result<25)
		{
			document.getElementById("resultLbl").innerHTML= result.toFixed(2) +"  - you are healthy";
		}
		else if(result>25)
		{ 
			document.getElementById("resultLbl").innerHTML= result.toFixed(2) +"  - you are overweight";
		}
	}

	else{
		alert("please fill out every box to see your BMI");
	} // end if 

} // end calculateBMI

	